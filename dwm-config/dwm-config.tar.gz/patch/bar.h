static void barhover(XEvent *e, Bar *bar);
static Bar *wintobar(Window win);
