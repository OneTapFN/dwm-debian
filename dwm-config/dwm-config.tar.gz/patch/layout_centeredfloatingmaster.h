static void centeredfloatingmaster(Monitor *m);

