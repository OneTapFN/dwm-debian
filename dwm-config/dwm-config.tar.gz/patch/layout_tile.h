static void tile(Monitor *m);

