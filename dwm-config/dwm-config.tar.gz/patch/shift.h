static Arg shift(const Arg *arg, int clients);
